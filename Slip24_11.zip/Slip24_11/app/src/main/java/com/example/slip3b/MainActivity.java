package com.example.slip3b;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    EditText e1,e2;
    RadioButton r1,r2,r3,r4;
    Button b1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1 = findViewById(R.id.editTextTextPersonName);
        e2 = findViewById(R.id.editTextTextPersonName2);

        b1 = findViewById(R.id.button);
        r1 = findViewById(R.id.radioButton);
        r2 = findViewById(R.id.radioButton2);
        r3 = findViewById(R.id.radioButton3);
        r4 = findViewById(R.id.radioButton4);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(r1.isChecked()){
                    e2.setText(e1.getText().toString().toUpperCase());
                } else if (r2.isChecked()) {
                    e2.setText(e1.getText().toString().toLowerCase());
                } else if (r3.isChecked()) {
                    String s1 = e1.getText().toString();
                    e2.setText(s1.substring(s1.length()-5));
                }  else if (r4.isChecked()) {
                    String s1 = e1.getText().toString();
                    e2.setText(s1.substring(0,5));
                }
            }
        });
    }
}