package com.example.resultintentave_pow;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class result_display extends AppCompatActivity {
    TextView tres;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_display);

        tres = findViewById(R.id.textview5);

        Bundle b1 = getIntent().getExtras();
        float s1 = b1.getFloat("RESULT");
        tres.setText(""+s1);
    }
}