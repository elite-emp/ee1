package com.example.resultintentave_pow;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText e1,e2;
    Button b1,b2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1 = findViewById(R.id.editTextTextPersonName);
        e2 = findViewById(R.id.editTextTextPersonName2);
        b1 = findViewById(R.id.button);
        b2 = findViewById(R.id.button2);
    }

    public void calAverage(View view) {
        int n1 = Integer.parseInt(e1.getText().toString());
        int n2 = Integer.parseInt(e2.getText().toString());

        Intent intnt = new Intent(this,result_display.class);

        int cnt=0,i,t=0;
        float sum=0;


        if(n1>n2)
        {
            t = n1;
            n1 = n2;
            n2 = t;
        }

        for(i=n1;i<=n2;i++)
        {
            sum += i;
            cnt++;
        }
        float avg = sum/cnt;
        intnt.putExtra("RESULT",avg);
        startActivity(intnt);
    }

    public void calPower(View view) {
        int n1 = Integer.parseInt(e1.getText().toString());
        int n2 = Integer.parseInt(e2.getText().toString());

        Intent intnt = new Intent(this,result_display.class);

        float power = (float)Math.pow(n1,n2);
        intnt.putExtra("RESULT",power);
        startActivity(intnt);
    }
}